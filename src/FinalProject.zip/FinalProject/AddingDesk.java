package FinalProject;

public class AddingDesk {
    private String wplaceID;
    private int floor;
    private int room;
    private int deskID;

    public void setWplaceID(String wplaceID) {
        this.wplaceID = wplaceID;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public void setDeskID(int deskID) {
        this.deskID = deskID;
    }

    public String getWplaceID() {
        return wplaceID;
    }
    public int getFloor () {
        return floor;
    }
    public int getRoom () {
        return room;
    }
    public int getDeskID () {
        return deskID;
    }

}